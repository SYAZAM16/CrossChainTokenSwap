// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "@ibc/core/IBCModule.sol";


contract TokenSwap is IBCModule {
    function completeSwap(address recipient, uint256 amount) public {
        require(msg.sender == owner, "Only owner can complete swap");
        balances[recipient] += amount;
    }
}

contract TokenSwap {
    address public owner;
    mapping(address => uint256) public balances;

    event SwapInitialized(address indexed sender, uint256 amount, string targetChain);

    constructor() {
        owner = msg.sender;
    }

    function deposit(uint256 amount) public {
        balances[msg.sender] += amount;
    }

    function swap(uint256 amount, string memory targetChain) public {
        require(balances[msg.sender] >= amount, "Insufficient balance");
        balances[msg.sender] -= amount;
        emit SwapInitialized(msg.sender, amount, targetChain);
    }

    function sendToPolkadot(address recipient, uint256 amount) public {
    require(balances[msg.sender] >= amount, "Not enough tokens");
    balances[msg.sender] -= amount;
    IBCModule.send(recipient, amount, "Polkadot");
}

}
